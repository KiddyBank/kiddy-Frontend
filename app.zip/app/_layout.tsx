import { Slot } from 'expo-router';
import React from 'react';
import 'react-native-reanimated';
import { AuthProvider } from './context/auth-context';

export default function RootLayout() {

  return (
    <AuthProvider>
      <Slot />
    </AuthProvider>
      );
}
