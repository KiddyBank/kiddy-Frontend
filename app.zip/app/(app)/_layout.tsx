import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { Slot, Stack, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import 'react-native-reanimated';
import { useColorScheme } from '@/hooks/useColorScheme';
import { useAuth } from '../context/auth-context';
import React from 'react';

export enum AccountType {
  PARENT = 1,
  KID = 2,
}

export default function AppLayout() {
  const router = useRouter();
  const { token, role, sub, login, logout, loading } = useAuth(); 
  const colorScheme = useColorScheme();

  useEffect(() => {
    console.log("started mounting app layout")
    if (loading) return;

    if (role === AccountType.PARENT) {
      router.replace('/parent-layout');
    } else if (role === AccountType.KID) {
      router.replace('/');
    } else {
      router.replace('/login-dialog');
    }
    console.log("finished mounting app layout")
  },  [role, router, loading]);


  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
        <Slot />
        <StatusBar style="auto" />
    </ThemeProvider>
  );
}
