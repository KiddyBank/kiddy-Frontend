import React from 'react';
import { Slot } from 'expo-router';

export default function AuthLayout() {
  return <Slot />;
}
